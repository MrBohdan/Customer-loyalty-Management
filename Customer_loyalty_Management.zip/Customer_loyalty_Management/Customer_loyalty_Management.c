#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include<io.h>
#include<fcntl.h>



int custmoers_menu();
int delete_member();
int View_list_of_customers();
int Add_reward();
int apply_reward();
int Add_member();
int Redeem_Reward();
int top_customers_menu();
int search_customer();
int exit_from_system();
int Edit_memberInfo();
int gift();

struct members {
	int id;
	int phone_num;
	float rewards;
	char name[20];
	char last_name[20];
	char gender[20];
	char address[20];
	//int delete;
};

struct members data;

int main() {
	int select;
	printf("\n|--------Select option-----------|\n");
	printf("|--------1)Customer--------------|\n");
	printf("|--------2)Reward----------------|\n");
	printf("|--------3)View list of customers----|\n");
	printf("|--------4)Exit from system------|\n\n");
	printf("|---------Select option-->>>>>");
	scanf("%d", &select);
	switch (select)
	{
	case 1:
		custmoers_menu();
		break;
	case 2:
		apply_reward();
		break;
	case 3:
		View_list_of_customers();
		break;
	case 4:
		exit_from_system();
		break;
	default:
		printf("\n|---------------Invalid input--------------|n");
		printf("\n|--------Press any key to continue---------|\n");
		main();
		break;
	}
	system("PAUSE");
	return 0;
}
int custmoers_menu() {
	int select;
	printf("\n\n|-------------Select option------------|\n");
	printf("|--------1)Add New Customer------------|\n");
	printf("|--------2)Delete Customer Detail------|\n");
	printf("|--------3)Edit Customer Detail--------|\n");
	printf("|--------4)View Customer Details-------|\n");
	printf("|--------5)Back to menu----------------|\n");
	printf("|--------6)Exit from system------------|\n");
	printf("\n\n");
	printf("|---------Select option-->>>>>");
	scanf_s(" %d", &select);
	switch (select)
	{
	case 1:
		Add_member();
		break;
	case 2:
		delete_member();
		break;
	case 3:
		Edit_memberInfo();
		break;
	case 4:
		search_customer();
		break;
	case 5:
		exit_from_system();
		break;
	default:
		printf("\n|---------------Invalid input--------------|n");
		printf("\n|--------Press any key to continue---------|\n");
		main();
		break;
	}
	system("PAUSE");
	return 0;
}


int apply_reward() {
	int select;
	printf("\n\n|---------------Select option------------|\n");
	printf("|-----1)Assigned Reward to Customer------|\n");
	printf("|-----2)Redeem Reward--------------------|\n");
	printf("|-----3)View available gift--------------|\n");
	printf("|-----4)Back to menu---------------------|\n");
	printf("|-----5)Exit from system-----------------|\n");
	printf("\n\n");
	printf("|--------Select option------>>");
	scanf_s(" %d", &select);
	switch (select)
	{
	case 1:
		Add_reward();
		break;
	case 2:
		Redeem_Reward();
		break;
	case 3:
		gift();
		break;
	case 4:
		main();
		break;
	case 5:
		exit_from_system();
		break;
	default:
		printf("\n|---------------Invalid input--------------|n");
		printf("\n|--------Press any key to continue---------|\n");
		main();
		break;
	}
	system("PAUSE");
	return 0;
}
int Add_reward() {
	FILE *file,*temporary_file;
	int if_found = 0, id_s;
	file = fopen("output.c", "rb");
	if (!file) {
		fprintf(stderr, "|---------Unable to open file %s", "data.dat-------\n");
		system("PAUSE");
		main();
		return -1;
	}
	temporary_file = fopen("temporary.c", "wb");
	if (!temporary_file) {
		fprintf(stderr, "|---------Unable to open file temp file.-------\n");
		system("PAUSE");
		main();
		return -1;
	}
	printf("Enter customer ID: ");
	scanf("%d", &id_s);
	while (fread(&data, sizeof(struct members), 1, file) != NULL) {
		if (id_s == data.id) {
			printf(">>>>A record with requested ID found.\n\n");
			printf("\n>>>>Assigned Reward to Customer.\n");
			printf("\nID\t:%d \n", data.id);
			printf(">Name\t: %s \n", data.name);
			printf(">Last name: %s  \n", data.last_name);
			printf(">Gender: %s \n", &data.gender);
			printf(">Phone\t: %d\n", &data.phone_num);
			printf(">Adddress: %s\n", data.address);
			printf("Current Rewards: %6.3f\t\n", data.rewards);
			printf(">>New Rewards\t: +");
			float a = data.rewards;
			float b;
			scanf("%f", &b);
			data.rewards = a + b;
			fwrite(&data, sizeof(struct members), 1, temporary_file);
			if_found = 1;
		}
		else {
			fwrite(&data, sizeof(struct members), 1, temporary_file);
		}
	}
	if (!if_found) {
		printf("|---------No record(s) found with the requested ID: %d-------|\n\n", id_s);
	}
	fclose(file);
	fclose(temporary_file);
	remove("output.c");
	rename("temporary.c", "output.c");
	system("PAUSE");
	main();
	return 0;
}

int search_customer() {
	FILE *file;
	int if_found = 0, id_s;
	file = fopen("output.c", "rb");
	if (!file) {
		fprintf(stderr, "|---------Unable to open file %s", "data.dat-------|\n");
		system("PAUSE");
		main();
		return -1;
	}
	printf("Enter customer ID: ");
	scanf("%d", &id_s);
	while (fread(&data, sizeof(struct members), 1, file) != NULL) {
		if (id_s == data.id) {
			printf("|---------A record with requested ID found.-------|\n\n");
			printf("\n|----ID\t:%d \n", data.id);
			printf("|----Name\t: %s \n", data.name);
			printf("|----Last name: %s \n", data.last_name);
			printf("|----Gender: %s \n", &data.gender);
			printf("|----Phone\t: %d \n", data.phone_num);
			printf("|----Adddress: %s \n", data.address);
			printf("|----Rewards\t: %6.3f \n", data.rewards);
			if_found = 1;
		}
	}
	if (!if_found) {
		printf("|---------No record(s) found with the requested ID: %d-------|\n\n", id_s);
	}

	fclose(file);
	system("PAUSE");
	main();
	return 0;
}
int Redeem_Reward() {
	FILE *file, *temporary_file;
	int if_found = 0, id_s;
	file = fopen("output.c", "rb");
	if (!file) {
		fprintf(stderr, "|---------Unable to open file %s", "data.dat-------\n");
		system("PAUSE");
		main();
		return -1;
	}
	temporary_file = fopen("temporary.c", "wb");
	if (!temporary_file) {
		fprintf(stderr, "|---------Unable to open file temp file.-------\n");
		system("PAUSE");
		main();
		return -1;
	}
	printf("Enter customer ID: ");
	scanf("%d", &id_s);
	while (fread(&data, sizeof(struct members), 1, file) != NULL) {
		if (id_s == data.id) {
			printf(">>>>A record with requested ID found.\n\n");
			printf("\n>>>>Assigned Reward to Customer.\n");
			printf("\n|----ID\t:%d \n", data.id);
			printf("|----Name\t: %s \n", data.name);
			printf("|----Last name: %s  \n", data.last_name);
			printf("|----Gender: %s \n", &data.gender);
			printf("|----Phone\t: %d\n", &data.phone_num);
			printf("|----Adddress: %s\n", data.address);
			printf("|----Current Rewards: %6.3f\t\n", data.rewards);
			printf("|---->>Rewards\t: -");
			float old_points = data.rewards;
			float new_points;
			scanf("%f", &new_points);
			data.rewards = old_points - new_points;
			fwrite(&data, sizeof(struct members), 1, temporary_file);
			if_found = 1;
		}
		else {
			fwrite(&data, sizeof(struct members), 1, temporary_file);
		}
	}
	if (!if_found) {
		printf("No record(s) found with the requested name: %d\n\n", id_s);
	}
	fclose(file);
	fclose(temporary_file);
	remove("output.c");
	rename("temporary.c", "output.c");
	system("PAUSE");
	main();
	return 0;
}
int gift() {
	FILE *file , *temporary_file;
	int if_found = 0, id_s;
	file = fopen("output.c", "rb");
	if (!file) {
		fprintf(stderr, "|---------Unable to open file %s", "data.dat-------\n");
		system("PAUSE");
		main();
		return -1;
	}
	temporary_file = fopen("temporary.c", "wb");
	if (!temporary_file) {
		fprintf(stderr, "|---------Unable to open file temp file.-------\n");
		system("PAUSE");
		main();
		return -1;
	}
	printf("Enter customer ID: ");
	scanf("%d", &id_s);
	while (fread(&data, sizeof(struct members), 1, file) != NULL) {
		if (id_s == data.id) {
			printf("|----A record with requested ID found.-----|\n\n");
			printf("\n|--------Assigned Reward to Customer.------|\n");
			printf("\n|----ID\t:%d \n", data.id);
			printf("|----Name\t: %s \n", data.name);
			printf("|----Last name: %s  \n", data.last_name);
			printf("|----Gender: %s \n", &data.gender);
			printf("|----Phone\t: %d\n", &data.phone_num);
			printf("|----Adddress: %s\n", data.address);
			printf("|----Current Rewards: %6.3f\t\n", data.rewards);
			printf("|---->>New Rewards\t: %f", data.rewards);
			float reward = data.rewards;
			float frame = 10, bear = 30, prosecco = 50, cushion = 80, house_hotel = 150, spa = 300, panasonic = 1500, Kia = 25000;
			printf("\n\nAvailable gifts\n");
			printf(">NOTE: Gifts displayed acording to your reward pints<\n");
			if (reward >= 10 && reward < 30) {
				printf("|---[1]Personalised Photo Frame Keepsake Box >>> ***10 points*** \n");
				printf("|---[2]Back to menu\n");
				printf("|--->>>Select: ");
				int selcet;
				scanf(" %d", &selcet);
				switch (selcet)
				{
				case 1:
					printf("\n|---From your account was removed: 10 points ");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					data.rewards = reward - frame;
					break;
				case 2:
					printf("\n");
					system("PAUSE");
					main();
					break;
				default:
					printf("\n");
					printf("|---Error---|");
					system("PAUSE");
					main();
					break;
				}
			}
			else if (reward >= 30 && reward < 50) {
				printf("|---[1]Personalised Photo Frame Keepsake Box >>> ***10 points*** \n");
				printf("|---[2]Personalised Teddy Bear>>> ***30 points***\n");
				printf("|---[3]Back to menu\n");
				printf("|--->>>Select: ");
				int selcet;
				scanf(" %d", &selcet);
				switch (selcet)
				{
				case 1:
					printf("\n|---From your account was removed: 10 points ");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					data.rewards = reward - frame;
					break;
				case 2:
					data.rewards = reward - bear;
					printf("\n|---From your account was removed: 30 points");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					break;
				case 3:
					printf("\n");
					system("PAUSE");
					main();
					break;
				default:
					printf("\n");
					printf("|---Error---|");
					system("PAUSE");
					main();
					break;
				}
			}
			else if (reward >= 50 && reward < 80) {
				printf("|---[1]Personalised Photo Frame Keepsake Box >>> ***10 points*** \n");
				printf("|---[2]Personalised Teddy Bear>>> ***30 points***\n");
				printf("|---[3]Personalised Prosecco>>> ***50 points***\n");
				printf("|---[4]Back to menu\n");
				printf("|--->>>Select: ");
				int selcet;
				scanf(" %d", &selcet);
				switch (selcet)
				{
				case 1:
					printf("\n|---From your account was removed: 10 points ");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					data.rewards = reward - frame;
					break;
				case 2:
					data.rewards = reward - bear;
					printf("\n|---From your account was removed: 30 points");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					break;
				case 3:
					data.rewards = reward - prosecco;
					printf("\n|---From your account was removed: 50 points");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					break;
				case 4:
					printf("\n");
					system("PAUSE");
					main();
					break;
				default:
					printf("\n");
					printf("|---Error---|");
					system("PAUSE");
					main();
					break;
				}
			}
			else if (reward >= 80 && reward < 150) {
				printf("|---[1]Personalised Photo Frame Keepsake Box >>> ***10 points*** \n");
				printf("|---[2]Personalised Teddy Bear>>> ***30 points***\n");
				printf("|---[3]Personalised Prosecco>>> ***50 points***\n");
				printf("|---[4]Moonlight Cushion>>> ***80 points***\n");
				printf("|---[5]Back to menu\n");
				printf("|--->>>Select: ");
				int selcet;
				scanf(" %d", &selcet);
				switch (selcet)
				{
				case 1:
					printf("\n|---From your account was removed: 10 points ");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					data.rewards = reward - frame;
					break;
				case 2:
					data.rewards = reward - bear;
					printf("\n|---From your account was removed: 30 points");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					break;
				case 3:
					data.rewards = reward - prosecco;
					printf("\n|---From your account was removed: 50 points");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					break;
				case 4:
					data.rewards = reward - cushion;
					printf("\n|---From your account was removed: 80 points");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					break;
				case 5:
					printf("\n");
					system("PAUSE");
					main();
					break;
				default:
					printf("\n");
					printf("|---Error---|");
					system("PAUSE");
					main();
					break;
				}
			}
			else if (reward >= 150 && reward < 250) {
				printf("|---[1]Personalised Photo Frame Keepsake Box >>> ***10 points*** \n");
				printf("|---[2]Personalised Teddy Bear>>> ***30 points***\n");
				printf("|---[3]Personalised Prosecco>>> ***50 points***\n");
				printf("|---[4]Moonlight Cushion>>> ***80 points***\n");
				printf("|---[5]Two Nights For The Price Of One Indulgent Break At Ardoe House Hotel>>> ***150 points***\n");
				printf("|---[6]Back to menu\n");
				printf("|--->>>Select: ");
				int selcet;
				scanf(" %d", &selcet);
				switch (selcet)
				{
				case 1:
					printf("\n|---From your account was removed: 10 points ");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					data.rewards = reward - frame;
					break;
				case 2:
					data.rewards = reward - bear;
					printf("\n|---From your account was removed: 30 points");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					break;
				case 3:
					data.rewards = reward - prosecco;
					printf("\n|---From your account was removed: 50 points");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					break;
				case 4:
					data.rewards = reward - cushion;
					printf("\n|---From your account was removed: 80 points");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					break;
				case 5:
					data.rewards = reward - house_hotel;
					printf("\n|---From your account was removed: 150 points");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					break;
				case 6:
					printf("\n");
					system("PAUSE");
					main();
					break;
				default:
					printf("\n");
					printf("|---Error---|");
					system("PAUSE");
					main();
					break;
				}
			}
			else if (reward >= 250 && reward < 25000) {
				printf("|---[1]Personalised Photo Frame Keepsake Box >>> ***10 points*** \n");
				printf("|---[2]Personalised Teddy Bear>>> ***30 points***\n");
				printf("|---[3]Personalised Prosecco>>> ***50 points***\n");
				printf("|---[4]Moonlight Cushion>>> ***80 points***\n");
				printf("|---[5]Two Nights For The Price Of One Indulgent Break At Ardoe House Hotel>>> ***150 points***\n");
				printf("|---[6]Three Night Spa Break With Dinner For Two>>> ***300 points***\n");
				printf("|---[7]Panasonic Lumix LX10>>> ***1500 points***\n");
				printf("|---[8]Back to menu\n");
				printf("|--->>>Select: ");
				int selcet;
				scanf(" %d", &selcet);
				switch (selcet)
				{
				case 1:
					printf("\n|---From your account was removed: 10 points ");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					data.rewards = reward - frame;
					break;
				case 2:
					data.rewards = reward - bear;
					printf("\n|---From your account was removed: 30 points");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					break;
				case 3:
					data.rewards = reward - prosecco;
					printf("\n|---From your account was removed: 50 points");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					break;
				case 4:
					data.rewards = reward - cushion;
					printf("\n|---From your account was removed: 80 points");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					break;
				case 5:
					data.rewards = reward - house_hotel;
					printf("\nFrom your account was removed: 150 points");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					break;
				case 6:
					data.rewards = reward - spa;
					printf("\n|---From your account was removed: 250 points");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					break;
				case 7:
					data.rewards = reward - panasonic;
					printf("\n|---From your account was removed: 1500 points");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					break;
				case 8:
					printf("\n");
					system("PAUSE");
					main();
					break;
				default:
					printf("\n");
					printf("|---Error---|");
					system("PAUSE");
					main();
					break;
				}
			}
			else if (reward >= 25000 && reward > 25000) {
				printf("|---[1]Personalised Photo Frame Keepsake Box >>> ***10 points*** \n");
				printf("|---[2]Personalised Teddy Bear>>> ***30 points***\n");
				printf("|---[3]Personalised Prosecco>>> ***50 points***\n");
				printf("|---[4]Moonlight Cushion>>> ***80 points***\n");
				printf("|---[5]Two Nights For The Price Of One Indulgent Break At Ardoe House Hotel>>> ***150 points***\n");
				printf("|---[6]Three Night Spa Break With Dinner For Two>>> ***300 points***\n");
				printf("|---[7]Panasonic Lumix LX10>>> ***1500 points***\n");
				printf("|---[8]2017 Kia Sorento SX **25000 points***\n");
				printf("|---[9]Back to menu\n");
				printf("|--->>>Select: ");
				int selcet;
				scanf(" %d", &selcet);
				switch (selcet)
				{
				case 1:
					printf("\n|---From your account was removed: 10 points ");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					data.rewards = reward - frame;
					break;
				case 2:
					data.rewards = reward - bear;
					printf("\n|---From your account was removed: 30 points");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					break;
				case 3:
					data.rewards = reward - prosecco;
					printf("\n|---From your account was removed: 50 points");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					break;
				case 4:
					data.rewards = reward - cushion;
					printf("\n|---From your account was removed: 80 points");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					break;
				case 5:
					data.rewards = reward - house_hotel;
					printf("\n|---From your account was removed: 150 points");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					break;
				case 6:
					data.rewards = reward - spa;
					printf("\n|---From your account was removed: 250 points");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					break;
				case 7:
					data.rewards = reward - panasonic;
					printf("\n|---From your account was removed: 1500 points");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					break;
				case 8:
					data.rewards = reward - Kia;
					printf("\n|---From your account was removed: 25000 points");
					printf("\n\nCongratulations, the gift will be sent to you within a few days\n\n");
					break;
				case 9:
					printf("\n");
					system("PAUSE");
					main();
					break;
				default:
					printf("\n");
					printf("|---Error---|");
					system("PAUSE");
					main();
					break;
				}
			}

			fwrite(&data, sizeof(struct members), 1, temporary_file);
			if_found = 1;

		}
		else {
			fwrite(&data, sizeof(struct members), 1, temporary_file);
		}
	}
	if (!if_found) {
		printf("No record(s) found with the requested name: %d\n\n", id_s);
	}
	fclose(file);
	fclose(temporary_file);
	remove("output.c");
	rename("temporary.c", "output.c");
	system("PAUSE");
	main();
	return 0;
}
int top_customers_menu() {
	int select;
	printf("\n\n>>>>>>>Select option<<<<<<<<\n");
	printf(">>>>>>>[1]View Customer Details\n");
	printf(">>>>>>>[2]Back to menu\n");
	printf("\n\n");
	printf(">>>>>>>-Select option-->>>>>");
	scanf_s(" %d", &select);
	switch (select)
	{
	case 1:
		View_list_of_customers();
		break;
	case 2:
		main();
		break;
	default:
		printf("\n>>>>>>>Invalid input<<<<<<<<\n");
		printf("\n>>>>>>>Press any key to continue<<<<<<<<\n");
		main();
		break;
	}
	return 0;
}

int Add_member() {
	FILE *file;
	// open Accounts file for writing
	file = fopen("output.c", "a+");
	if (file == NULL)
	{
		fprintf(stderr, "\n|---------Error opening file-------\n\n");
		main();
		return -1;
	}
	// endlessly read from keyboard and write to file
	printf("\n|------------------------------------Registration---------------------------------|\n");
	printf("\n|----------------Please enter the following customer information.-----------------|\n");
	printf("\n|------NOTE: ID and Phone number just in integer numbers and rewards inf float.---|\n");
	printf("\nID\t: ");
	scanf("%d", &data.id);
	printf("Name\t: ");
	scanf("%s", data.name);
	printf("Last name: ");
	scanf("%s", data.last_name);
	printf("Gender: ");
	scanf("%s", &data.gender);
	printf("Phone\t: ");
	scanf("%d", &data.phone_num);
	printf("Adddress: ");
	scanf("%s", data.address);
	printf("Rewards\t: ");
	scanf("%f", &data.rewards);
	// write entire structure to Accounts file
	printf("\n>>>>>>>>>>>SYSTEM: New member is Added Successfully.\n");
	fwrite(&data, sizeof(struct members), 1, file);
	fclose(file);
	system("PAUSE");
	main();
	return 0;
}

int View_list_of_customers() {
	FILE *file;
	file = fopen("output.c", "rb");
	if (file == NULL)
	{
		fprintf(stderr, "\nError opening data.txt\n\n");
		main();
	}
	printf("|-------------------------Custemers inforamation-------------------------|\n");

	while (fread(&data, sizeof(struct members), 1, file) != NULL) {
		printf("ID: %d\t Name: %s\t Last name: %s \t  Gender: %s\t  Phone number: %d\t Address: %s\t Rewards: %6.3f\t\n", 
			data.id, data.name, data.last_name, data.gender, data.phone_num, data.address, data.rewards);
	}
	fclose(file);
	system("PAUSE");
	main();
	return 0;
}
int Edit_memberInfo() {
	FILE *file,*temporary_file;
	int if_found = 0,id_s;
	file = fopen("output.c", "rb");
	if (!file) {
		fprintf(stderr, "|---------Unable to open file %s", "data.dat-------\n");
		system("PAUSE");
		main();
		return -1;
	}
	temporary_file = fopen("temporary.c", "wb");
	if (!temporary_file) {
		fprintf(stderr, "|---------Unable to open file temp file.-------\n");
		system("PAUSE");
		main();
		return -1;
	}
	printf("Enter customer ID: ");
	scanf("%d", &id_s);
	while (fread(&data, sizeof(struct members), 1, file) != NULL) {
		if (id_s == data.id) {
			printf("A record with requested ID found.\n\n");
			printf("ID: %d\t \nName: %s\t \nLast name: %s \t  \nGender: %s\t  \nPhone number: %d\t \nAddress: %s\t \nRewards: %6.3f\t\n",
				data.id, data.name, data.last_name, data.gender, data.phone_num, data.address, data.rewards);
			printf("\nPlease enter new customer information.\n");
			printf("\nID\t:%d \n", data.id);
			printf("New Name\t: ");
			scanf("%s", data.name);
			printf("New Last name: ");
			scanf("%s", data.last_name);
			printf("New Gender: ");
			scanf("%s", &data.gender);
			printf("New Phone\t: ");
			scanf("%d", &data.phone_num);
			printf("New Adddress: ");
			scanf("%s", data.address);
			printf("New Rewards\t: ");
			scanf("%f", &data.rewards);
			fwrite(&data, sizeof(struct members), 1, temporary_file);
			if_found = 1;
		}
		else {
			fwrite(&data, sizeof(struct members), 1, temporary_file);
		}
	}
	if (!if_found) {
		printf("No record(s) found with the requested name: %d\n\n", id_s);
	}
	fclose(file);
	fclose(temporary_file);
	remove("output.c");
	rename("temporary.c", "output.c");
	system("PAUSE");
	main();
	return 0;
}
int delete_member() {
	FILE *file,*temporary_file;
	int if_found = 0,id_s;
	file = fopen("output.c", "rb");
	if (!file) {
		fprintf(stderr, "|---------Unable to open file %s", "data.dat-------\n");
		system("PAUSE");
		main();
		return -1;
	}
	temporary_file = fopen("temporary.c", "wb");
	if (!temporary_file) {
		fprintf(stderr, "|---------Unable to open file temp file.-------\n");
		system("PAUSE");
		main();
		return -1;
	}
	printf("Enter ID: ");
	scanf("%d", &id_s);
	while (fread(&data, sizeof(struct members), 1, file) != NULL) {
		if (id_s == data.id) {
			printf("A record with requested ID found and deleted.\n\n");
			printf("ID: %d\t \nName: %s\t \nLast name: %s \t  \nGender: %s\t  \nPhone number: %d\t \nAddress: %s\t \nRewards: %6.3f\t\n",
				data.id, data.name, data.last_name, data.gender, data.phone_num, data.address, data.rewards);
			if_found = 1;
		}
		else {
			fwrite(&data, sizeof(struct members), 1, temporary_file);
		}
	}
	if (!if_found) {
		printf("No record(s) found with the requested name: %d\n\n", id_s);
	}
	fclose(file);
	fclose(temporary_file);
	remove("output.c");
	rename("temporary.c", "output.c");
	system("PAUSE");
	main();
	return 0;
}
int exit_from_system() {
	int  select;
	printf("|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|\n|");
	printf("|---------Are you want to exit ?-------|\n");
	printf("|-----1)Yes\n");
	printf("|-----2)No\n");
	scanf_s(" %d", &select);
	switch (select)
	{
	case 1:
		system("PAUSE");
		exit(EXIT_SUCCESS);
		break;
	case 2:
		main();
		break;
	default:
		printf("\n|---------Invalid input-------\n");
		printf("\n|---------Press any key to continue-------\n");
		main();
		break;
	}
	return 0;
}

	